<?php
    if (isset($_GET['message']))
        echo $_GET['message'];
?>