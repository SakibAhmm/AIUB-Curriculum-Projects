<!DOCTYPE html>
<html lang="en">
<head>
    <title>RegistrationForm</title>
</head>
<body>
<h1>RegistrationForm</h1>
  <form action="registrationProcess.php" method="post">
    
    Firstname: <input type="text" name="firstname" > <br>
    Lastname: <input type="text" name="lastname" > <br>
    Email: <input type="text" name="email" > <br>
    Password: <input type="password" name="password" > <br>
    Phone: <input type="text" name="phone" > <br>
    Gender: <input type="text" name ="gender" > 
    <button type="submit">Register</button> 
  </form>  
</body>
</html>